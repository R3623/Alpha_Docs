import React, { Component } from 'react'

export class Hero extends Component {
  render() {
    return (
      <div>Hero</div>
    )
  }
}

export default Hero