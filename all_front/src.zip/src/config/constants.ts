// Use Vite environment variable when available, otherwise fallback to localhost
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string) || 'http://localhost:8000/api';
// URL de connexion du Mobile (Flutter Web) avec port fixe
export const MOBILE_LOGIN_URL = 'http://localhost:5173/#/login';
export const LOGIN_URL = MOBILE_LOGIN_URL;
export const CITOYEN_URL = MOBILE_LOGIN_URL;

export const ROLES = {
  CITOYEN: 'citoyen',
  RESPONSABLE: 'responsable',
  CHEF_DE_SERVICE: 'chef_de_service',
  AGENT: 'agent',
} as const;

export const PORTS = {
  REACT_APP: 5173,
  LOGIN_PAGE: 8080,
  BACKEND: 8000,
} as const;
 