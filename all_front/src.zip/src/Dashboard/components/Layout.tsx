import React, { useState } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import { Outlet } from 'react-router-dom';
import '../assets/Layout.scss';

const Layout: React.FC = () => {

  return (
    <div className="layout">
      <div style={{ display: 'flex', position: 'relative' }}>
        <Sidebar/>
        <main style={{ flex: 1, padding: '0' , position: 'relative'}}>
          <Header />
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
