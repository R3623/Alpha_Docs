import React, { Component } from 'react'
import { MdMessage } from 'react-icons/md'
import { BsCardList, BsSend } from 'react-icons/bs'
import { BiFontSize, BiLeftArrowAlt, BiMessageAdd } from 'react-icons/bi'
import User from '../assets/user-2579217217.png'
import { CgAdd } from 'react-icons/cg'

// Utilitaire cookie (même logique que dans AgentCreate)
const getCookie = (name: string): string | null => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) {
    const cookieValue = parts.pop()?.split(';').shift() || null;
    return cookieValue;
  }
  return null;
};

// Types
type MiniUser = { id: number; nom_complet: string; role: string; photo?: string | null };

type MsgListesProps = { onClose?: () => void };

type MessageItem = { id?: number; content: string; sender: number; recipient: number; created_at?: string };
type ThreadItem = { otherId: number; other?: MiniUser | null; last: MessageItem; unread?: number };

type MsgListesState = {
  mode: 'list' | 'conversation' | 'new';
  isDragging: boolean;
  dragOffsetX: number;
  dragOffsetY: number;
  posX: number;
  posY: number;
  currentUser: { id: number | null; role: string | null };
  recipients: MiniUser[]; // pour l'écran "nouveau message"
  usersById: Record<number, MiniUser>;
  threads: ThreadItem[];
  loadingList: boolean;
  selectedRecipient: MiniUser | null;
  messages: MessageItem[];
  inputValue: string;
  search: string;
  searchResults: MiniUser[];
};

export class MsgListes extends Component<MsgListesProps, MsgListesState> {
  containerRef: React.RefObject<HTMLDivElement | null>;
  socket: WebSocket | null = null;

  constructor(props: MsgListesProps) {
    super(props);
    this.state = {
      mode: 'list',
      isDragging: false,
      dragOffsetX: 0,
      dragOffsetY: 0,
      posX: 0,
      posY: 0,
      currentUser: { id: null, role: null },
      recipients: [],
      usersById: {},
      threads: [],
      loadingList: true,
      selectedRecipient: null,
      messages: [],
      inputValue: '',
      search: '',
      searchResults: [],
    };
    this.containerRef = React.createRef<HTMLDivElement>();
  }

  componentDidMount(): void {
    const uid = Number(getCookie('user_id') || 0) || null;
    const role = (getCookie('role') || '').toLowerCase() || null;
    const sessionId = getCookie('sessionid');

    console.log('=== RESPONSABLE AUTHENTICATION DEBUG ===');
    console.log('User ID:', uid);
    console.log('User Role:', role);
    console.log('Session ID:', sessionId);
    console.log('All cookies:', document.cookie);
    console.log('=====================================');

    this.setState({ currentUser: { id: uid, role } }, async () => {
      // Authentifier l'utilisateur auprès de Django si nécessaire
      if (uid && role) {
        console.log('Authenticating responsable user...');
        await this.authenticateUser();

        // Charger les données utilisateur après authentification
        this.loadUsersIndex();
        this.loadThreads();
      } else {
        console.log('Missing user credentials for responsable');
      }
    });
  }

  // Authentification personnalisée auprès de Django pour les responsables
  authenticateUser = async () => {
    try {
      console.log('=== RESPONSABLE CUSTOM AUTHENTICATION ===');

      // Étape 1: Vérifier si nous avons déjà une session valide
      const sessionResponse = await fetch('http://localhost:8000/api/current_user/', {
        method: 'GET',
        credentials: 'include',
      });

      console.log('Session check response status:', sessionResponse.status);

      if (sessionResponse.ok) {
        const sessionData = await sessionResponse.json();
        console.log('Session check successful:', sessionData);

        if (sessionData.success && sessionData.data) {
          console.log('✅ Responsable already has valid Django session');
          return true;
        }
      }

      // Étape 2: Si pas de session valide, utiliser l'authentification personnalisée
      console.log('🔄 Creating Django session for responsable...');

      const authResponse = await fetch('http://localhost:8000/api/auth/custom-authenticate/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          // Les données seront récupérées depuis les cookies côté serveur
        })
      });

      console.log('Custom auth response status:', authResponse.status);

      if (authResponse.ok) {
        const authData = await authResponse.json();
        console.log('Custom authentication successful:', authData);

        if (authData.success) {
          console.log('✅ Responsable Django session created successfully');
          return true;
        } else {
          console.error('❌ Custom authentication failed:', authData.message);
          return false;
        }
      } else {
        const errorText = await authResponse.text();
        console.error('❌ Custom authentication request failed:', authResponse.status, errorText);
        return false;
      }
    } catch (error) {
      console.error('❌ Authentication error:', error);
      return false;
    }
  };

  componentWillUnmount(): void {
    document.removeEventListener('mousemove', this.handleMouseMove);
    document.removeEventListener('mouseup', this.handleMouseUp);
    this.closeSocket();
  }

  // Index utilisateurs pour mapping noms + liste pour "nouveau"
  loadUsersIndex = async () => {
    try {
      const opt: RequestInit = { credentials: 'include' };
      const [ra, rr] = await Promise.all([
        fetch('http://localhost:8000/api/utilisateurs/?role=agent', opt),
        fetch('http://localhost:8000/api/utilisateurs/?role=responsable', opt),
      ]);
      const [agents, responsables] = await Promise.all([ra.json(), rr.json()]);
      const all: MiniUser[] = [...(agents || []), ...(responsables || [])]
        .map((u: any) => ({ id: u.id, nom_complet: u.nom_complet || `${u.first_name} ${u.last_name}`, role: (u.role || '').toLowerCase(), photo: u.photo || null }))
        .filter((u: MiniUser) => ['agent', 'responsable'].includes(u.role));
      const { currentUser } = this.state;
      const usersById = all.reduce((acc: Record<number, MiniUser>, u: MiniUser) => {
        acc[u.id] = u;
        return acc;
      }, {});
      // Filter recipients based on current user's role
      let allowedRoles: string[] = [];
      if (currentUser.role === 'responsable') {
        allowedRoles = ['agent'];
      } else if (currentUser.role === 'agent') {
        allowedRoles = ['responsable'];
      }
      this.setState({
        recipients: all.filter(u => u.id !== currentUser.id && allowedRoles.includes(u.role)),
        usersById,
      });
    } catch (e) {
      // ignore
    }
  }

  // Charger les fils de discussion existants (ce qui concerne uniquement l'utilisateur courant)
  loadThreads = async () => {
    try {
      const { currentUser, usersById } = this.state;
      if (!currentUser.id) {
        console.log('No current user ID, skipping loadThreads');
        this.setState({ loadingList: false });
        return;
      }
      const opt: RequestInit = { credentials: 'include' };
      console.log('Loading threads for user:', currentUser.id);
      const res = await fetch('http://localhost:8000/api/messages/', opt);
      console.log('API response status:', res.status);
      if (!res.ok) {
        console.error('API request failed:', res.status, res.statusText);
        this.setState({ loadingList: false });
        return;
      }
      const raw = await res.json();
      console.log('Raw messages data:', raw);
      const data: MessageItem[] = (raw || []).map(this.toMsg);
      const mine = data.filter(m => m.sender === currentUser.id || m.recipient === currentUser.id);
      console.log('Filtered messages for current user:', mine.length);
      // grouper par autre participant
      const byOther: Record<number, MessageItem[]> = {};
      for (const m of mine) {
        const otherId = m.sender === currentUser.id ? m.recipient : m.sender;
        if (!byOther[otherId]) byOther[otherId] = [];
        byOther[otherId].push(m);
      }
      const threads: ThreadItem[] = Object.entries(byOther).map(([otherIdStr, msgs]) => {
        const otherId = Number(otherIdStr);
        msgs.sort((a, b) => new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime());
        const last = msgs[msgs.length - 1];
        return { otherId, other: usersById[otherId] || null, last };
      }).sort((a, b) => new Date(b.last.created_at || 0).getTime() - new Date(a.last.created_at || 0).getTime());
      console.log('Created threads:', threads.length);
      this.setState({ threads, loadingList: false });
    } catch (e) {
      console.error('Error in loadThreads:', e);
      this.setState({ loadingList: false });
    }
  };

  // Charger l'historique d'une conversation depuis l'API
  loadConversationHistory = async () => {
    try {
      const { currentUser, selectedRecipient } = this.state;
      if (!currentUser.id || !selectedRecipient) return;
      const opt: RequestInit = { credentials: 'include' };
      const res = await fetch('http://localhost:8000/api/messages/', opt);
      const raw = await res.json();
      const data: MessageItem[] = (raw || []).map(this.toMsg);
      const history = data.filter(m =>
        (m.sender === currentUser.id && m.recipient === selectedRecipient.id) ||
        (m.recipient === currentUser.id && m.sender === selectedRecipient.id)
      ).sort((a, b) => new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime());
      this.setState({ messages: history });
    } catch (e) {
      // ignore
    }
  };

  // Fonction de diagnostic pour déboguer l'authentification
  debugAuthentication = async () => {
    console.log('=== RESPONSABLE AUTHENTICATION DIAGNOSTIC ===');
    console.log('Current User State:', this.state.currentUser);
    console.log('All Cookies:', document.cookie);

    // Tester l'endpoint current_user
    try {
      const response = await fetch('http://localhost:8000/api/current_user/', {
        method: 'GET',
        credentials: 'include',
      });
      console.log('Current User Response Status:', response.status);
      if (response.ok) {
        const data = await response.json();
        console.log('Current User Response Data:', data);
      } else {
        console.log('Current User Response Error:', await response.text());
      }
    } catch (error) {
      console.log('Current User Fetch Error:', error);
    }

    // Tester l'authentification personnalisée
    try {
      const authResponse = await fetch('http://localhost:8000/api/auth/custom-authenticate/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });
      console.log('Custom Auth Response Status:', authResponse.status);
      if (authResponse.ok) {
        const authData = await authResponse.json();
        console.log('Custom Auth Response Data:', authData);
      } else {
        console.log('Custom Auth Response Error:', await authResponse.text());
      }
    } catch (error) {
      console.log('Custom Auth Fetch Error:', error);
    }

    console.log('===========================================');
  };

  // Recherche utilisateur par nom (filtrage côté client pour éviter le renvoi global de l'API)
  searchUsers = async (q: string) => {
    const term = (q || '').trim().toLowerCase();
    if (term.length < 1) {
      this.setState({ searchResults: [] });
      return;
    }
    const ensureFilter = (list: MiniUser[]) => {
      const { currentUser } = this.state;
      let allowedRoles: string[] = [];
      if (currentUser.role === 'responsable') {
        allowedRoles = ['agent'];
      } else if (currentUser.role === 'agent') {
        allowedRoles = ['responsable'];
      }
      const filtered = (list || [])
        .filter(u => allowedRoles.includes((u.role || '').toLowerCase()))
        .filter(u => u.id !== (currentUser.id || 0))
        .filter(u => (u.nom_complet || '').toLowerCase().includes(term));
      // dédoublonner par id
      const uniq = Array.from(new Map(filtered.map(u => [u.id, u])).values());
      return uniq;
    };
    try {
      const opt: RequestInit = { credentials: 'include' };
      // On récupère la liste complète puis on filtre côté client pour garantir la pertinence
      const res = await fetch('http://localhost:8000/api/utilisateurs/', opt);
      const arr = await res.json();
      const mapped: MiniUser[] = (arr || []).map((u: any) => ({
        id: u.id,
        nom_complet: u.nom_complet || `${u.first_name} ${u.last_name}`,
        role: (u.role || '').toLowerCase(),
        photo: u.photo || null,
      }));
      const results = ensureFilter(mapped);
      this.setState({ searchResults: results });
    } catch (e) {
      // Fallback sur les données locales si l'API échoue
      const { recipients, usersById } = this.state;
      const merged = [...(recipients || []), ...Object.values(usersById || {})];
      this.setState({ searchResults: ensureFilter(merged) });
    }
  };

  // Gestion drag
  handleMouseDown = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (e.button !== 0) return;
    const rect = this.containerRef.current?.getBoundingClientRect();
    if (rect) {
      this.setState({ isDragging: true, dragOffsetX: e.clientX - rect.left, dragOffsetY: e.clientY - rect.top });
      document.addEventListener('mousemove', this.handleMouseMove);
      document.addEventListener('mouseup', this.handleMouseUp);
    }
  };

  handleMouseMove = (e: MouseEvent) => {
    if (!this.state.isDragging) return;
    let newX = e.clientX - this.state.dragOffsetX;
    let newY = e.clientY - this.state.dragOffsetY;
    const width = this.containerRef.current?.offsetWidth || 400;
    const height = this.containerRef.current?.offsetHeight || 500;
    newX = Math.max(0, Math.min(window.innerWidth - width, newX));
    newY = Math.max(0, Math.min(window.innerHeight - height, newY));
    this.setState({ posX: newX, posY: newY });
  };

  handleMouseUp = () => {
    this.setState({ isDragging: false });
    document.removeEventListener('mousemove', this.handleMouseMove);
    document.removeEventListener('mouseup', this.handleMouseUp);
  };

  // Sélection d'un destinataire (ouvrir la conversation)
  handleSelectRecipient = (user: MiniUser) => {
    this.setState({ mode: 'conversation', selectedRecipient: user, messages: [] }, async () => {
      await this.loadConversationHistory();
      this.openSocket();
    });
  };

  // Retour
  handleBackToList = () => {
    this.closeSocket();
    this.setState({ mode: 'list', selectedRecipient: null, messages: [], inputValue: '' });
  };

  handleNewMessage = () => {
    this.setState({ mode: 'new', selectedRecipient: null, messages: [], inputValue: '' });
  };

  // WebSocket helpers
  computeRoomName = (a: number, b: number) => {
    const low = Math.min(a, b);
    const high = Math.max(a, b);
    return `${low}_${high}`;
  };

  openSocket = () => {
    this.closeSocket();
    const { currentUser, selectedRecipient } = this.state;
    if (!currentUser.id || !selectedRecipient) {
      console.log('❌ Cannot open WebSocket: missing user or recipient', { userId: currentUser.id, recipient: !!selectedRecipient });
      return;
    }

    const room = this.computeRoomName(currentUser.id, selectedRecipient.id);
    // Utiliser le port 8000 directement pour Django
    const url = `ws://localhost:8000/ws/chat/${room}/`;
    console.log('=== RESPONSABLE WEBSOCKET DEBUG ===');
    console.log('WebSocket URL:', url);
    console.log('Current User ID:', currentUser.id);
    console.log('Current User Role:', currentUser.role);
    console.log('Selected Recipient ID:', selectedRecipient.id);
    console.log('Selected Recipient Role:', selectedRecipient.role);
    console.log('Room name:', room);
    console.log('All cookies:', document.cookie);
    console.log('================================');

    try {
      this.socket = new WebSocket(url);
      console.log('✅ WebSocket instance created for responsable');

      this.socket.onopen = (event) => {
        console.log('✅ WebSocket connected successfully for responsable');
        console.log('WebSocket readyState:', this.socket?.readyState);
      };

      this.socket.onmessage = (event) => {
        console.log('📨 Responsable WebSocket message received:', event.data);
        try {
          const payload = JSON.parse(event.data);
          console.log('📨 Parsed WebSocket payload:', payload);
          const data = this.toMsg(payload);
          if (data && data.content && (data.sender || data.recipient)) {
            const me = this.state.currentUser.id!;

            // Skip if this is a message sent by the current user (already handled by API response)
            if (data.sender === me) {
              console.log('⚠️ Skipping duplicate message from self via WebSocket');
              return;
            }

            console.log('✅ Processing valid message for responsable:', data);
            this.setState(prev => {
              const msgs = [...prev.messages, data];
              const otherId = data.sender === me ? data.recipient : data.sender;
              let found = false;
              const updatedThreads = (prev.threads || []).map(t => {
                if (t.otherId === otherId) {
                  found = true;
                  return { ...t, last: data };
                }
                return t;
              });
              if (!found) {
                updatedThreads.unshift({ otherId, other: prev.usersById[otherId] || null, last: data });
              }
              updatedThreads.sort((a, b) => new Date(b.last.created_at || 0).getTime() - new Date(a.last.created_at || 0).getTime());
              return { messages: msgs, threads: updatedThreads };
            });
          } else {
            console.log('⚠️ Ignoring invalid message format for responsable');
          }
        } catch (e) {
          console.error('❌ Error parsing WebSocket message for responsable:', e);
        }
      };

      this.socket.onclose = (event) => {
        console.log('❌ Responsable WebSocket disconnected');
        console.log('Close code:', event.code);
        console.log('Close reason:', event.reason);
        console.log('Was clean:', event.wasClean);
      };

      this.socket.onerror = (error) => {
        console.error('❌ Responsable WebSocket error occurred:', error);
        console.log('WebSocket readyState:', this.socket?.readyState);
      };

    } catch (e) {
      console.error('❌ Error creating WebSocket for responsable:', e);
    }
  };

  closeSocket = () => {
    try {
      if (this.socket) {
        this.socket.close();
      }
    } finally {
      this.socket = null;
    }
  };

  // Map backend message payload to UI shape
  toMsg = (m: any): MessageItem => ({
    id: m?.id,
    content: m?.content || '',
    sender: (m?.sender_id ?? m?.sender) as number,
    recipient: (m?.receiver_id ?? m?.recipient) as number,
    created_at: m?.created_at || undefined,
  });

  handleSend = async () => {
    const { inputValue, currentUser, selectedRecipient } = this.state;
    const content = (inputValue || '').trim();
    if (!content || !currentUser.id || !selectedRecipient) {
      console.log('❌ Send validation failed:', { content: !!content, userId: currentUser.id, recipient: !!selectedRecipient });
      return;
    }

    console.log('=== RESPONSABLE SENDING MESSAGE ===');
    console.log('Content:', content);
    console.log('Sender ID:', currentUser.id);
    console.log('Sender Role:', currentUser.role);
    console.log('Recipient ID:', selectedRecipient.id);
    console.log('Recipient Role:', selectedRecipient.role);

    try {
      const requestBody = JSON.stringify({
        sender_id: currentUser.id,
        receiver_id: selectedRecipient.id,
        content,
      });
      console.log('Request body:', requestBody);

      // Get CSRF token from cookies
      const csrftoken = getCookie('csrftoken');
      console.log('CSRF token:', csrftoken);
      console.log('All cookies before send:', document.cookie);

      const res = await fetch('http://localhost:8000/api/messages/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrftoken || ''
        },
        credentials: 'include',
        body: requestBody,
      });

      console.log('POST response status:', res.status);
      console.log('POST response headers:', Object.fromEntries(res.headers.entries()));

      if (!res.ok) {
        const errorText = await res.text().catch(() => 'Unable to read error response');
        console.error('❌ Message POST failed:', res.status, errorText);
        return;
      }

      const responseData = await res.json();
      console.log('✅ POST response data:', responseData);
      const saved = this.toMsg(responseData);

      this.setState(prev => {
        const msgs = [...prev.messages, saved];
        const otherId = selectedRecipient.id;
        let found = false;
        const updatedThreads = (prev.threads || []).map(t => {
          if (t.otherId === otherId) {
            found = true;
            return { ...t, last: saved };
          }
          return t;
        });
        if (!found) {
          updatedThreads.unshift({ otherId, other: prev.usersById[otherId] || selectedRecipient, last: saved });
        }
        updatedThreads.sort((a, b) => new Date(b.last.created_at || 0).getTime() - new Date(a.last.created_at || 0).getTime());
        return { inputValue: '', messages: msgs, threads: updatedThreads };
      });

      // IMPORTANT: Ne PAS envoyer via WebSocket car le backend Channels s'en charge déjà
      // Le message sera automatiquement diffusé à tous les participants de la conversation
      console.log('✅ Message sent via API - WebSocket diffusion handled by backend');
    } catch (e) {
      console.error('❌ Error sending message for responsable:', e);
    }
  };

  renderList = () => {
    const { threads, loadingList, search, usersById, searchResults } = this.state;
    return (
      <>
        <div className="titleContent">
          <BsCardList className='ico'/>
          <p>Tous</p>
          <p>Non lue</p>
        </div>
        <div className="content">
          <div style={{padding: '6px 10px'}}>
            <input
              type="search"
              placeholder="Rechercher..."
              value={search}
              onChange={e => { const v = e.target.value; this.setState({search: v}); this.searchUsers(v); }}
              style={{width:'100%', padding:'6px 8px', borderRadius:4, fontSize:'13px', outline:'none', borderBottom:'1px solid #b3adad3d'}}
            />
            <div className="rsul">
              {searchResults && searchResults.length > 0 && (
                <div style={{width:'100%', height:'405px', display:'flex', flexDirection:'column', gap:'2px', paddingTop:'5px', position:'relative', overflow:'hidden'}}>
                  {searchResults.map(u => (
                    <div key={u.id} style={{display:'flex', alignItems:'center', padding:'6px 10px', cursor:'pointer', background:'#ffffff13'}} onClick={() => this.handleSelectRecipient(u)}>
                      <img src={User} alt="" style={{width:25, height:25, borderRadius:'50%', marginRight:8, border:'1px solid #ffffff38'}}/>
                      <span style={{fontSize:'13px', color:'#021a20c4'}}>{u.nom_complet} <span style={{opacity:.6, fontSize:'12px', color:'#ffffffb0'}}>({u.role})</span></span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          {loadingList && <p style={{padding:10, fontSize:'13px', color:'white'}}>Chargement...</p>}
          {!loadingList && threads.map(t => {
            const u = t.other || usersById[t.otherId] || { id: t.otherId, nom_complet: `Utilisateur #${t.otherId}`, role: '', photo: null } as MiniUser;
            return (
              <div key={t.otherId} className="contentLue" onClick={() => this.handleSelectRecipient(u)} style={{cursor:'pointer'}}>
                <div className="photo"><img src={User} alt="" /></div>
                <div className="msg">
                  <div className="msgtop">
                    <h3>{u.nom_complet}</h3>
                    {/* Option heure */}
                  </div>
                  <div className="msgbottom">
                    <p style={{opacity:.8}}>{t.last.content}</p>
                  </div>
                </div>
              </div>
            );
          })}
          <div className="NewMsg" onClick={this.handleNewMessage}><BiMessageAdd className='new'/></div>
        </div>
      </>
    );
  };

  renderConversation = () => {
    const { selectedRecipient, messages, inputValue } = this.state;
    if (!selectedRecipient) return null;
    return (
      <>
        <div className="titleMsg">
          <BiLeftArrowAlt className='retour' style={{cursor: 'pointer'}} onClick={this.handleBackToList}/>
          <div className="userMsg">
            <div className="photo"><img src={User} alt="" /></div>
            <p style={{fontSize:'13px'}}>{selectedRecipient.nom_complet}</p>
          </div>
        </div>
        <div className="contentWriter">
          <div className="MsgContenu">
            {messages.map((m, idx) => (
              <div key={idx} className={m.sender === this.state.currentUser.id ? 'send' : 'receive'}>
                <p>{m.content}</p>
              </div>
            ))}
          </div>
          <div className="Writer">
            <div className="writerContent">
              <CgAdd className='addImg'/>
              <textarea id="writer" placeholder='Ecrivez votre messages ....' value={inputValue} onChange={e => this.setState({inputValue: e.target.value})} style={{fontSize:'13px'}}/>
              <BsSend className='sender' onClick={this.handleSend} style={{cursor:'pointer'}} />
            </div>
          </div>
        </div>
      </>
    );
  };

  renderNew = () => {
    // Pour l'instant, identique à la liste mais avec composition directe
    return (
      <>
        <div className="titleNew" style={{display: 'flex'}}>
          <BiLeftArrowAlt className='retour' style={{cursor: 'pointer', color: 'white', fontSize:'25px', marginRight:'10px'}} onClick={this.handleBackToList}/>
          <BiMessageAdd className='newmsg'/>
          <h3>Nouveau message</h3>
        </div>
        <div className="contentNew" style={{display: 'block'}}>
          <div className="searchUser">
            <p>à : </p>
            <input type="search" placeholder='taper ou rechercher ici le nom de destinataire ...' value={this.state.search} onChange={e => this.setState({search: e.target.value})} />
          </div>
          <div style={{width:'100%', height:'265px', display:'flex', flexDirection:'column', gap:'2px', position:'relative', overflow:'hidden'}}>
            {this.state.recipients.filter(u => u.nom_complet.toLowerCase().includes(this.state.search.toLowerCase())).map(u => (
              <div key={u.id} style={{display:'flex', alignItems:'center', padding:'6px 10px', cursor:'pointer', background:'#ffffff13'}} onClick={() => this.handleSelectRecipient(u)}>
                <img src={User} alt="" style={{width:25, height:25, borderRadius:'50%', marginRight:8, border:'1px solid #ffffff38'}}/>
                <span style={{fontSize:'13px', color:'#021a20c4'}}>{u.nom_complet} <span style={{opacity:.6, fontSize:'12px', color:'#ffffffb0'}}>({u.role})</span></span>
              </div>
            ))}
          </div>
          <div className="writerNew">
            <textarea placeholder='Ecrire ici votre message...' value={this.state.inputValue} onChange={e=>this.setState({inputValue: e.target.value})} style={{fontSize:'13px'}}></textarea>
            <div className="icones">
              <CgAdd className='icon'/>
              <BsSend className='icon' onClick={this.handleSend}/>
            </div>
          </div>
        </div>
      </>
    );
  };

  render() {
    const { mode, posX, posY, isDragging } = this.state;
    return (
      <div
        className='MsgListes'
        ref={this.containerRef}
        style={{ position: 'fixed', left: posX, top: posY, zIndex: 1000, cursor: isDragging ? 'grabbing' : 'default', userSelect: isDragging ? 'none' : 'auto' }}
      >
        <div className="title" style={{ cursor: isDragging ? 'grabbing' : 'grab', userSelect: 'none' }} onMouseDown={this.handleMouseDown}>
          <h4><span><MdMessage/></span>Messages</h4>
          <div style={{display: 'flex', gap: '5px'}}>
            <button
              onClick={this.debugAuthentication}
              style={{
                background: '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: '3px',
                padding: '2px 6px',
                fontSize: '10px',
                cursor: 'pointer'
              }}
              title="Diagnostiquer l'authentification"
            >
              🔧
            </button>
            <p style={{cursor: 'pointer'}} onClick={this.props.onClose}>x</p>
          </div>
        </div>
        <div className="contentListes">
          {mode === 'list' && this.renderList()}
          {mode === 'conversation' && this.renderConversation()}
          {mode === 'new' && this.renderNew()}
        </div>
      </div>
    )
  }
}

export default MsgListes
