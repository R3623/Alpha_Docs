import React, { Component } from 'react'

export class Membres extends Component {
  render() {
    return (
      <div>Membres</div>
    )
  }
}

export default Membres