import React, { Component } from 'react'

export class Calendar extends Component {
  render() {
    return (
      <div>Calendar</div>
    )
  }
}

export default Calendar