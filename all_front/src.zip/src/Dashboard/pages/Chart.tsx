import React, { Component } from 'react'

export class Chart extends Component {
  render() {
    return (
      <div>Chart</div>
    )
  }
}

export default Chart