import React, { Component } from 'react'

export class Aide extends Component {
  render() {
    return (
      <div>Aide</div>
    )
  }
}

export default Aide