import React, { Component } from 'react'
import Sary from '../assets/user.png'
import { BsEmojiSmile, BsInbox, BsListNested, BsPencilSquare, BsSend } from 'react-icons/bs'
import { BiArchive, BiCircle, BiPen, BiSearch, BiShare, BiX } from 'react-icons/bi'
import { MdCall, MdDelete, MdLabelImportant, MdSmsFailed, MdUploadFile, MdVideoCall } from 'react-icons/md'
import '../assets/Messages.scss'
import User from '../assets/user.png'

export class Messages extends Component {
  state = {
  showNewMsg: false,
  showWriter: false,
  selectedUserName: "",
  selectedUserImage: null
}

  render() {
    return (
      <div className='Messages'>
        <div className="side">
          <div className="navigation">
            <div className="navs active">
              <div className="icon">
                <BsInbox />
              </div>
              <p>Tous les messages</p>
            </div>
            <div className="navs">
              <div className="icon">
                <BsSend />
              </div>
              <p>Envoyé</p>
            </div>
            <div className="navs">
              <div className="icon">
                <BiPen />
              </div>
              <p>Brouillon</p>
            </div>
            <div className="navs">
              <div className="icon">
                <MdSmsFailed />
              </div>
              <p>Non envoyé</p>
            </div>
            <div className="navs">
              <div className="icon">
                <BsInbox />
              </div>
              <p>Spam</p>
            </div>
            <div className="navs">
              <div className="icon">
                <BiArchive />
              </div>
              <p>Archive</p>
            </div>
            {/* <div className="navs">
              <div className="icon">
                <MdLabelImportant />
              </div>
              <p>Important</p>
            </div> */}
          </div>
          <div className="membres">
            <div className="title">
              <h3>Membres</h3>
            </div>
            <div className="listes">
              <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
              </div>
              <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
              <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
              <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
              <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
               <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
               <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
               <div className="membre">
               <div className="profil">
                 <div className="img">
                    <img src={User} alt="" />
                  </div>
                  <p>John Doe</p>
               </div>
               <div className="status">
                <p></p>
               </div>
               
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <div className="headers">
              <div className="search">
                <input type="search" name="" id="" placeholder='rechercher une personne ou message ......' />
                <BiSearch className='icon'/>
              </div>
              <div className="nbr">
                <p>Nombres des messages :</p>
                <span>180</span>
                <BsListNested className='icon'/>
              </div>
          </div>
          <div className="btn_new" onClick={() => this.setState({ showNewMsg: true })}>
            <div className="new">
              <BsPencilSquare className='icon'/>
              <p>Nouveaux messages</p>
            </div>
          </div>
          <div className="content">
            <div className="head">
              <div className="navs">
                <div className="icon">
                  <BsInbox />
                </div>
                <p>Tous les messages</p>
              </div>
              <div className="outils">
                <div className="delete">
                  <MdDelete />
                  <p>Supprimer</p>
                </div>
                {/* <div className="share">
                  <BiShare />
                  <p>Partager</p>
                </div> */}
              </div>
            </div>
            <div className="contenu">
                <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                 <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur. kdj</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                 <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
                 <div className="listes" onClick={() => this.setState({ showWriter: true })}>
                  <div className="" style={{display:'flex', alignItems:'center', gap:'20px'}}>
                    <div className="check">
                      <p></p>
                    </div>
                    <div className="msg">
                      <div className="photo">
                        <img src={User} alt="" />
                      </div>
                      <div className="contenu">
                        <div className="name">
                          <p>John Doe</p>
                          <span className='date'>10 : 10</span>
                        </div>
                        <div className="obj">
                          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi praesentium deserunt id aliquam aliquid voluptatum? Ducimus, optio! Error esse provident quae cupiditate ea sapiente tempore animi cum, consequatur velit aspernatur.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="action">
                    < MdDelete title='supprimer'/>
                  </div>
                </div>
            </div>
          </div>
        </div>
         <div 
          className="writer_click"
          style={{ display: this.state.showWriter ? "flex" : "none" }}
        >
          <div className="container">
            <div className="header">
              <div className="profil">
                <div className="photo">
                  <img src={User} alt="" />
                </div>
                <p className="name">Jean paule</p>
              </div>
              <div className="call">
                <MdCall />
                <MdVideoCall className='video'/>
                <BiX className="x" onClick={() => this.setState({ showWriter: false })}/>

              </div>
            </div>
            <div className="contenu">
              <div className="msg">
                <div className="recu">
                  <p>Vola-tena ngah?</p>
                  <span className='datemsg'>10:10</span>
                </div>
                <div className="envoyer">
                  <p>Vola-tena?</p>
                  <div className='datemsg'>10:10</div>
                </div>
                <div className="in_writer">
                  <img src={User} alt="azerty" />
                  <p className='c1'><BiCircle className='circle'/></p>
                  <p className='c2'><BiCircle className='circle'/></p>
                  <p className='c1'><BiCircle className='circle'/></p>
                </div>
              </div>
              <div className="writer">
                <textarea name="" id="" placeholder='ecrire votre message ....'></textarea>
                <div className="outils">
                  <div className="insert">
                    <MdUploadFile />
                    <BsEmojiSmile />
                  </div>
                  <div className="sender">
                    <BsSend />
                    <p>Envoyer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div 
          className="new_msg" 
          style={{ display: this.state.showNewMsg ? "flex" : "none" }}
        >

          <div className="container">
            <div className="header">
              <p>Nouveau messages</p>
              <BiX className='x' onClick={() => this.setState({ showNewMsg: false })}/>
            </div>
            <div className="contenu">
              <div className="inp_search">
                <input type="search" name="" id="" placeholder='recherche ....' />
                <BiSearch className='srch'/>
              </div>
              <div className="result">
                <div className="list">
                  <p className="name"></p>
                </div>
              </div>
              <div className="vers">
                <div className="profil">
                  <div className="photo">
                    {this.state.selectedUserImage && (
                      <img src={this.state.selectedUserImage} alt="" />
                    )}

                  </div>
                  <p className="name"></p>
                </div>
              </div>
              <div className="writer">
                <textarea name="" id="" placeholder='ecrire votre message ....'></textarea>
                <div className="outils">
                  <div className="insert">
                    <MdUploadFile />
                    <BsEmojiSmile />
                  </div>
                  <div className="sender">
                    <BsSend />
                    <p>Envoyer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Messages