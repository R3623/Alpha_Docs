import React, { Component } from 'react'

export class Settings extends Component {
  render() {
    return (
      <div>Settings</div>
    )
  }
}

export default Settings