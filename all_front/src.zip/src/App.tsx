import React from 'react';
import { Routes, Route } from 'react-router-dom';
import RespoRoutes from './RespoRoutes';
// import ProtectedRoute from './ProtectedRoute';
import './Dashboard/assets/indexStyle.scss';
import './index.css';
import ConnectRoutes from './ConnectRoutes';
import WebsiteRoutes from './Website_routes';

function App() {
  return (
    <div className='App'>
      <Routes>
        <Route path='/*' element={<WebsiteRoutes />} />
        <Route path='/connect/*' element={<ConnectRoutes />} />
        <Route path="/dashboard/*" element={<RespoRoutes />} />
      </Routes>
    </div>
  );
}

export default App;