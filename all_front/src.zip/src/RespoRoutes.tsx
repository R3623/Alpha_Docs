import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Layout from './Dashboard/components/Layout';
import { AccueilDash } from './Dashboard/pages/AccueilDash';
import Messages from './Dashboard/pages/Messages';
import Chart from './Dashboard/pages/Chart';
import Membres from './Dashboard/pages/Membres';
import Calendar from './Dashboard/pages/Calendar';
import Aide from './Dashboard/pages/Aide';
import Settings from './Dashboard/pages/Settings';

const RespoRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<AccueilDash />} />
        <Route path="Messages" element={<Messages />} />
        <Route path="Chart" element={<Chart />} />
        <Route path="Membres" element={<Membres />} />
        <Route path="Calendar" element={<Calendar />} />
        <Route path="Aide" element={<Aide />} />
        <Route path="Settings" element={<Settings />} />
      </Route>
    </Routes>
  );
};

export default RespoRoutes;
