// import React, { useContext, useEffect, useState } from 'react';
// import { Navigate } from 'react-router-dom';
// // import { AuthContext } from './context/AuthContext';
// import type { ReactNode } from 'react';
// import { LuLoaderCircle } from 'react-icons/lu';
// import './assets/LoadStyle.scss'

// interface ProtectedRouteProps {
//   children: ReactNode;
//   requiredRoles: string[];
// }

// import { MOBILE_LOGIN_URL } from './config/constants';

// const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredRoles }) => {
//   const authContext = useContext(AuthContext);
//   const [showLoading, setShowLoading] = useState(true); 

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       setShowLoading(false); 
//     }, 1000);

//     return () => clearTimeout(timer);
//   }, []);

//   if (!authContext) {
//     return null;
//   }

//   const { isAuthenticated, role, loading } = authContext;

  
//   if (loading || showLoading) {
//     return (
//       <div style={{ width: '100%', height: '100vh', display: 'flex', alignItems: 'center',  }}>
//         <h1 style={{ width: '500px', margin: 'auto', fontSize: '20px', textAlign: 'center', padding: '10px', borderRadius: '50px', color: 'white' }}>
//           <LuLoaderCircle className='load' />
//           <span className='span' style={{ marginLeft: '20px', textAlign: 'left' }}>Loading...</span>
//         </h1>
//       </div>
//     );
//   }

//   if (!isAuthenticated || !role || !requiredRoles.includes(role)) {
//     // Vérifier si l'utilisateur est déjà authentifié via les cookies
//     const getCookie = (name: string): string | null => {
//       const value = `; ${document.cookie}`;
//       const parts = value.split(`; ${name}=`);
//       if (parts.length === 2) {
//         const cookieValue = parts.pop()?.split(';').shift() || null;
//         return cookieValue;
//       }
//       return null;
//     };
    
//     const cookieRole = getCookie('role');
    
//     if (cookieRole && requiredRoles.includes(cookieRole)) {
//       // L'utilisateur est authentifié via les cookies, mettre à jour l'état
//       if (authContext) {
//         authContext.setIsAuthenticated(true);
//         authContext.setRole(cookieRole);
//         const cookieUserName = getCookie('nom_complet');
//         authContext.setUserName(cookieUserName || 'Utilisateur');
//         const cookieService = getCookie('service');
//         authContext.setService(cookieService || null);
//       }
//       return <>{children}</>;
//     } else {
//       // Rediriger vers l'application mobile pour la connexion
//       window.location.href = MOBILE_LOGIN_URL;
//       return null;
//     }
//   }

//   return <>{children}</>;
// };

// export default ProtectedRoute;
