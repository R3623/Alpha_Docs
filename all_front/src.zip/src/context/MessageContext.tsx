import React, { createContext, useState, useContext } from 'react';

interface MessageContextType {
  isMsgVisible: boolean;
  toggleMsgVisibility: () => void;
  closeMsg: () => void;
}

const MessageContext = createContext<MessageContextType | undefined>(undefined);

export const MessageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMsgVisible, setIsMsgVisible] = useState(false);

  const toggleMsgVisibility = () => {
    setIsMsgVisible(!isMsgVisible);
  };

  const closeMsg = () => {
    setIsMsgVisible(false);
  };

  return (
    <MessageContext.Provider value={{ isMsgVisible, toggleMsgVisibility, closeMsg }}>
      {children}
    </MessageContext.Provider>
  );
};

export const useMessage = () => {
  const context = useContext(MessageContext);
  if (context === undefined) {
    throw new Error('useMessage must be used within a MessageProvider');
  }
  return context;
};