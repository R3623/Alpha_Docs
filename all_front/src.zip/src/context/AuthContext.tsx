// import React, { createContext, useState, useEffect } from 'react';
// import { MOBILE_LOGIN_URL } from '../config/constants';
// import type { ReactNode } from 'react';

// interface AuthContextType {
//   isAuthenticated: boolean;
//   setIsAuthenticated: React.Dispatch<React.SetStateAction<boolean>>;
//   role: string | null;
//   setRole: React.Dispatch<React.SetStateAction<string | null>>;
//   userName: string | null;
//   setUserName: React.Dispatch<React.SetStateAction<string | null>>;
//   service: string | null;
//   setService: React.Dispatch<React.SetStateAction<string | null>>;
//   loading: boolean;
//   logout: () => void;
// }

// export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// interface AuthProviderProps {
//   children: ReactNode;
// }

// const getCookie = (name: string): string | null => {
//   const value = `; ${document.cookie}`;
//   const parts = value.split(`; ${name}=`);
//   if (parts.length === 2) {
//     const cookieValue = parts.pop()?.split(';').shift() || null;
//     return cookieValue;
//   }
//   return null;
// };

// const deleteCookie = (name: string): void => {
//   document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=${window.location.hostname};`;
// };

// export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);
//   const [role, setRole] = useState<string | null>(null);
//   const [userName, setUserName] = useState<string | null>(null);
//   const [service, setService] = useState<string | null>(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const checkAuth = async () => {
//       try {
//         // 1) Support SSO: récupérer role et user_id depuis l'URL (provenant du Mobile)
//         const params = new URLSearchParams(window.location.search);
//         const ssoRole = params.get('role');
//         const ssoUserId = params.get('user_id');
//         if (ssoRole && ssoUserId && (ssoRole === 'responsable' || ssoRole === 'chef_de_service' || ssoRole === 'agent')) {
//           try {
//             // Récupérer les infos utilisateur (dont service) sans cookie de session
//             const res = await fetch(`http://localhost:8000/api/utilisateurs/${ssoUserId}/`, { credentials: 'include' });
//             if (res.ok) {
//               const user = await res.json();
//               setIsAuthenticated(true);
//               setRole(user.role || ssoRole);
//               setUserName(user.nom_complet || 'Utilisateur');
//               // user.service est probablement un ID numérique selon CurrentUserView
//               // ici l'endpoint retourne l'objet complet -> prendre user.service ou user.service?.id
//               const srv = user.service?.id ?? user.service ?? null;
//               setService(srv ? String(srv) : null);

//               // Stocker les informations dans les cookies pour persister l'authentification
//               const expires = new Date();
//               expires.setDate(expires.getDate() + 7); // 7 jours d'expiration
//               document.cookie = `role=${user.role || ssoRole}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `nom_complet=${user.nom_complet || 'Utilisateur'}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `service=${srv ? String(srv) : ''}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `user_id=${ssoUserId}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;

//               // Nettoyer l'URL après l'authentification SSO réussie
//               const cleanUrl = window.location.pathname;
//               window.history.replaceState({}, document.title, cleanUrl);

//               setLoading(false);
//               return;
//             }
//           } catch (e) {
//             console.error('SSO fetch user failed', e);
//           }
//           // Fallback si la récupération échoue
//           setIsAuthenticated(true);
//           setRole(ssoRole);
//           setUserName('Utilisateur');
//           setService(null);

//           // Stocker les informations dans les cookies pour persister l'authentification
//           const expires = new Date();
//           expires.setDate(expires.getDate() + 7); // 7 jours d'expiration
//           document.cookie = `role=${ssoRole}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//           document.cookie = `nom_complet=Utilisateur; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//           document.cookie = `user_id=${ssoUserId}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;

//           // Nettoyer l'URL même en cas de fallback
//           const cleanUrl = window.location.pathname;
//           window.history.replaceState({}, document.title, cleanUrl);

//           setLoading(false);
//           return;
//         }

//         const cookieRole = getCookie('role');
//         const cookieUserName = getCookie('nom_complet');
//         const cookieService = getCookie('service');
//         const cookieUserId = getCookie('user_id');
        
//         if (cookieRole && cookieUserName) {
//           // Si nous avons des cookies d'authentification, vérifier si l'utilisateur est toujours valide
//           if (cookieUserId) {
//             // Vérifier si l'utilisateur existe toujours
//             try {
//               const res = await fetch(`http://localhost:8000/api/utilisateurs/${cookieUserId}/`, { credentials: 'include' });
//               if (res.ok) {
//                 const user = await res.json();
//                 setIsAuthenticated(true);
//                 setRole(user.role || cookieRole);
//                 setUserName(user.nom_complet || cookieUserName);
//                 const srv = user.service?.id ?? user.service ?? null;
//                 setService(srv ? String(srv) : (cookieService || null));
//                 setLoading(false);
//                 return;
//               }
//             } catch (e) {
//               console.error('Failed to verify user from cookie', e);
//             }
//           }
          
//           // Fallback aux cookies existants
//           setIsAuthenticated(true);
//           setRole(cookieRole);
//           setUserName(cookieUserName);
//           setService(cookieService || null);
//         } else {
//           // Vérifier l'authentification via l'API Django
//           const res = await fetch('http://localhost:8000/api/current_user/', {
//             credentials: 'include'
//           });
          
//           if (res.ok) {
//             const data = await res.json();
//             if (data.success && data.data) {
//               setIsAuthenticated(true);
//               setRole(data.data.role);
//               setUserName(data.data.nom_complet || `${data.data.first_name} ${data.data.last_name}`);
//               setService(data.data.service ? String(data.data.service) : null);
              
//               // Stocker les informations dans les cookies
//               const expires = new Date();
//               expires.setDate(expires.getDate() + 7); // 7 jours d'expiration
//               document.cookie = `role=${data.data.role}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `nom_complet=${data.data.nom_complet || `${data.data.first_name} ${data.data.last_name}`}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `service=${data.data.service ? String(data.data.service) : ''}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//               document.cookie = `user_id=${data.data.id}; path=/; domain=${window.location.hostname}; expires=${expires.toUTCString()};`;
//             } else {
//               clearAuthData();
//             }
//           } else {
//             clearAuthData();
//           }
//         }
//       } catch (err) {
//         console.error('Erreur lors de la vérification de l\'authentification:', err);
//         clearAuthData();
//       } finally {
//         setLoading(false);
//       }
//     };

//     checkAuth();
//   }, []);

//   const clearAuthData = () => {
//     setIsAuthenticated(false);
//     setRole(null);
//     setUserName(null);
//     setService(null);
//     deleteCookie('userId');
//     deleteCookie('role');
//     deleteCookie('nom_complet');
//     deleteCookie('cin');
//     deleteCookie('service');
//     deleteCookie('user_id');
//   };


//   const logout = async () => {
//     try {
//       await fetch('http://localhost:8000/api/logout/', {
//         method: 'POST',
//         credentials: 'include',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           // Si nous avons un user_id dans les cookies, l'envoyer pour une déconnexion plus précise
//           user_id: getCookie('user_id')
//         })
//       });
//     } catch (err) {
//       console.error('Erreur lors de la déconnexion:', err);
//     } finally {
//       clearAuthData();
//       window.location.href = MOBILE_LOGIN_URL;
//     }
//   };

//   return (
//     <AuthContext.Provider value={{
//       isAuthenticated,
//       setIsAuthenticated,
//       role,
//       setRole,
//       userName,
//       setUserName,
//       service,
//       setService,
//       loading,
//       logout
//     }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };
